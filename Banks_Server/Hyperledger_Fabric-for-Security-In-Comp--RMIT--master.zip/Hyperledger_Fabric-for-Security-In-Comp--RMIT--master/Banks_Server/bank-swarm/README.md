# 4host-swarm
Deploy multi-host First Network (using Fabric v2.2)

Source of article: https://medium.com/@kctheservant/multi-host-deployment-for-first-network-hyperledger-fabric-v2-273b794ff3d
