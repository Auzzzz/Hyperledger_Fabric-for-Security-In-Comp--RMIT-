docker-compose -f host3.yaml up -d
